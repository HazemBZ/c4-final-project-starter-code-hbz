
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'hazembz',
  applicationName: 'serverless-todo-app',
  appUid: '49Q2mcvlRY46QzzhC2',
  orgUid: '315abbfc-eca4-4b9d-b541-ec0003e2f00c',
  deploymentUid: '78541c8e-2e19-4c6a-9703-49ec41f0e473',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-UpdateTodo', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/updateTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}